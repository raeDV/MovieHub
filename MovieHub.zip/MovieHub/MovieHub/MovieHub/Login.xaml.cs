﻿using System;
using System.Data.SqlClient;
using System.Windows;

namespace MovieHub
{
    /// <summary>
    /// Interaction logic for Login.xaml
    /// </summary>

    public partial class Login : Window
    {
        SqlConnection con;
        public Login()
        {
            InitializeComponent();
        }

        private void login_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string connectionString = "Data Source=DESKTOP-QAJII73\\SQLEXPRESS;Initial Catalog=Movie;Integrated Security=True";
                con = new SqlConnection(connectionString);
                con.Open();
                string query = "SELECT COUNT(*) FROM Account WHERE username COLLATE SQL_Latin1_General_CP1_CS_AS = @Username AND password COLLATE SQL_Latin1_General_CP1_CS_AS = @Password";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("Username", username.Text);
                cmd.Parameters.AddWithValue("Password", password.Password);

                //Execute the query
                int count = Convert.ToInt32(cmd.ExecuteScalar());

                if ((count == 1) && (username.Text.Equals("chester") || username.Text.Equals("sneha")))
                {
                    MessageBox.Show("ADMIN Account Successfully Logged in!");
                    con.Close();
                    Movie movieAdmin = new Movie();
                    movieAdmin.Show();
                    this.Close();
                }
                else if (count == 1)
                {
                    MessageBox.Show("Account Successfully Logged in!");
                    con.Close();
                    MovieUser movieuser = new MovieUser();
                    movieuser.Show();
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Invalid Username or Password!");
                    con.Close();

                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            con.Close();
        }

        private void back_Click(object sender, RoutedEventArgs e)
        {
            MainWindow main = new MainWindow();
            main.Show();
            this.Close();
        }
    }
}
