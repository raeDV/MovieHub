﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MovieHub
{
    /// <summary>
    /// Interaction logic for RegisteredAccounts.xaml
    /// </summary>
    public partial class RegisteredAccounts : Window
    {
        public RegisteredAccounts()
        {
            InitializeComponent();
        }
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            using SqlConnection con = new SqlConnection("Data Source=desktop-qajii73\\sqlexpress;Initial Catalog=Movie;Integrated Security=True");
            {
                con.Open();

                SqlCommand cmd = new SqlCommand("SELECT First_name, Last_Name, Date_of_birth, Email FROM Account ORDER BY First_name ASC;", con);
                SqlDataAdapter adp = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                adp.Fill(ds, "LoadDataBinding");
                datagrid.DataContext = ds;

                con.Close();
            }
        }
    }
}
