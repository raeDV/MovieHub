﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace MovieHub
{
    /// <summary>
    /// Interaction logic for WatchMovie.xaml
    /// </summary>
    public partial class WatchMovie : Window
    {
        private TimeSpan remainingTime;
        private DispatcherTimer timer;

        public WatchMovie()
        {
            InitializeComponent();
            remainingTime = TimeSpan.FromMinutes(90);
            UpdateCountdownLabel();
        }

        private void pauseButton_Click(object sender, RoutedEventArgs e)
        {
            if (timer != null)
            {
                timer.Stop();
            }
        }

        private void playButton_Click(object sender, RoutedEventArgs e)
        {
            if (timer == null)
            {
                timer = new DispatcherTimer();
                timer.Interval = TimeSpan.FromSeconds(1);
                timer.Tick += timer_Tick;
            }
            timer.Start();
        }

        private void stopButton_Click(object sender, RoutedEventArgs e)
        {
            if (timer != null)
            {
                timer.Stop();
                remainingTime = TimeSpan.FromMinutes(90); 
                UpdateCountdownLabel();
            }
        }

       private void timer_Tick(object sender, EventArgs e)
        {
            remainingTime = remainingTime.Subtract(TimeSpan.FromSeconds(1));
            if (remainingTime <= TimeSpan.Zero)
            {
                timer.Stop();
                MessageBox.Show("Movie finish!");
                remainingTime = TimeSpan.FromMinutes(1); // reset the countdown time
            }
            UpdateCountdownLabel();
        }

        private void UpdateCountdownLabel()
        {
            countdownLabel.Content = remainingTime.ToString(@"hh\:mm\:ss");
        }

        private void back_Click(object sender, RoutedEventArgs e)
        {
            PurchasedMovieList pml = new PurchasedMovieList();
            pml.Show();
            this.Close();
        }
    }
}
