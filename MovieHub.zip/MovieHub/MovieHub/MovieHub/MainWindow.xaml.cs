﻿using System.Windows;

namespace MovieHub
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {        
        public MainWindow()
        {
            InitializeComponent();
        }

        private void login_Click(object sender, RoutedEventArgs e)
        {            
            Login login = new Login();
            login.Show();
            this.Close();
        }

        private void register_Click(object sender, RoutedEventArgs e)
        {            
            Register register = new Register();
            register.Show();
            this.Close();
        }
    }
}
