﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Microsoft.VisualBasic;

namespace MovieHub
{
    /// <summary>
    /// Interaction logic for PurchasedMovieList.xaml
    /// </summary>
    public partial class PurchasedMovieList : Window
    {
        SqlConnection con = new SqlConnection("Data Source=desktop-qajii73\\sqlexpress;Initial Catalog=Movie;Integrated Security=True");

        public PurchasedMovieList()
        {
            InitializeComponent();
        }
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            con.Open();
            string userInput = Interaction.InputBox("Please enter your Username:", "Input Box", "");
            if (userInput != "")
            {
                string user = "Select count(*) from Account where username COLLATE SQL_Latin1_General_CP1_CS_AS = @Username";

                SqlCommand cmd1 = new SqlCommand(user, con);

                cmd1.Parameters.AddWithValue("Username", userInput);
                int count = Convert.ToInt32(cmd1.ExecuteScalar());

                if (count == 1)
                {
                    SqlCommand cmd = new SqlCommand("Select ID, Title, Year, Genre from Purchase where Username = @Username And Expiration_Date = 'UNLIMITED' OR Expiration_Date > Purchase_Date", con);
                    cmd.Parameters.AddWithValue("Username", userInput);                    
                    SqlDataAdapter adp = new SqlDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    adp.Fill(ds, "LoadDataBinding");
                    datagrid.DataContext = ds;
                }
                else
                {
                    MessageBox.Show("Account does not Exist!");
                    MovieUser mu = new MovieUser();
                    mu.Show();
                    this.Close();
                }
            }
            con.Close();
        }

        private void back_Click(object sender, RoutedEventArgs e)
        {
            MovieUser mu = new MovieUser();
            mu.Show();
            this.Close();
        }

        private void play_Click(object sender, RoutedEventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=desktop-qajii73\\sqlexpress;Initial Catalog=Movie;Integrated Security=True");
            con.Open();
            DataRowView selectedRow = (DataRowView)datagrid.SelectedItem;

            if (selectedRow == null)
            {
                MessageBox.Show("Please Select Movie First!");
            }
            else
            {
                WatchMovie wm = new WatchMovie();
                wm.Show();
                this.Close();
            }
        }
    }
}
