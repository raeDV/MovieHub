﻿using Microsoft.VisualBasic;
using System;
using System.Data.SqlClient;
using System.Windows;

namespace MovieHub
{
    /// <summary>
    /// Interaction logic for Balance.xaml
    /// </summary>
    public partial class Deposit : Window
    {
        SqlConnection con = new SqlConnection("Data Source=desktop-qajii73\\sqlexpress;Initial Catalog=Movie;Integrated Security=True");

        public Deposit()
        {
            InitializeComponent();
        }

        private void deposit_Click(object sender, RoutedEventArgs e)
        {
            con.Open();
            string userInput = Interaction.InputBox("Please enter your Username:", "Input Box", "");
            if (userInput != "")
            {
                string amountInput = Interaction.InputBox("Please enter the deposit amount:", "Input Box", "");
                decimal amount;
                if (decimal.TryParse(amountInput, out amount) && amount > 0)
                {
                    string query = "Select count(*) from Payment where Username COLLATE SQL_Latin1_General_CP1_CS_AS = @Username";

                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("Username", userInput);

                    int count = Convert.ToInt32(cmd.ExecuteScalar());
                    if (count == 1)
                    {
                        string query1 = "Update Payment set Balance = Balance + @Balance where Username COLLATE SQL_Latin1_General_CP1_CS_AS = @Username";

                        SqlCommand com = new SqlCommand(query1, con);

                        com.Parameters.AddWithValue("@Balance", amount);
                        com.Parameters.AddWithValue("@Username", userInput);

                        com.ExecuteNonQuery();

                        MessageBox.Show("$" + amount.ToString() + " Has been added into your Account");
                    }
                    else
                    {
                        MessageBox.Show("Payment Card does not Exist!");
                    }
                }
                else
                {
                    MessageBox.Show("Invalid deposit amount!");
                }
            }
            else
            {
                MessageBox.Show("Please Check your Username and Try Again!");
            }
            con.Close();
        }
    }
}
