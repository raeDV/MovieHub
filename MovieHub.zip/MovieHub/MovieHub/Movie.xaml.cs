﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Net.Http;
using System.Net.Http.Json;
using System.Windows;
using MovieHub.Models;
using RestAPITesting.Models;

namespace MovieHub
{
    /// <summary>
    /// Interaction logic for Movie.xaml
    /// </summary>
    public partial class Movie : Window
    {
        HttpClient client = new HttpClient();
        SqlConnection con = new SqlConnection("Data Source=desktop-qajii73\\sqlexpress;Initial Catalog=Movie;Integrated Security=True");
        public Movie()
        {
            client.BaseAddress = new Uri("https://localhost:7288/api/Movie/");
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
            InitializeComponent();
        }
        private void insert_Click(object sender, RoutedEventArgs e)
        {
            addMovie();
        }

        private void update_Click(object sender, RoutedEventArgs e)
        {
            updateMovie();
        }

        private void search_Click(object sender, RoutedEventArgs e)
        {
            listMoviesById();
        }

        private void delete_Click(object sender, RoutedEventArgs e)
        {
            deleteMovieById();
        }

        private void main_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Account Logged out Successfully!");
            MainWindow main = new MainWindow();
            main.Show();
            this.Close();
        }
        private async void addMovie()
        {
            Movies movie = new Movies();
            movie.ID = int.Parse(id.Text);
            movie.Title = title.Text;
            movie.Year = int.Parse(year.Text);
            movie.Genre = genre.Text;
            movie.RentPrice = float.Parse(rent.Text);
            movie.BuyPrice = float.Parse(buy.Text);

            HttpResponseMessage response = await client.PostAsJsonAsync<Movies>("AddMovie/", movie);

            //get the response from restAPI server
            Status.Content = response.StatusCode.ToString();
        }

        private void listMoviesById()
        {
            var response = client.GetFromJsonAsync<Response>("GetAllMoviesByID/" + int.Parse(id.Text));

            Models.Movies movie = response.Result.movies;

            if (movie != null)
            {
                title.Text = movie.Title;
                year.Text = movie.Year.ToString();
                genre.Text = movie.Genre;
                rent.Text = movie.RentPrice.ToString();
                buy.Text = movie.BuyPrice.ToString();

                Status3.Content = response.Result.StatusMessage;
            }
            else
            {
                Status3.Content = response.Result.StatusMessage;
            }
        }

        private async void deleteMovieById()
        {
            HttpResponseMessage response = await client.DeleteAsync("DeleteMovie/" + int.Parse(id.Text));
            if (response != null)
            {
                Status2.Content = response.StatusCode.ToString();
            }
            else
            {
                MessageBox.Show("ID does not Exist!");
            }
        }

        private async void updateMovie()
        {
            Movies movie = new Movies();
            movie.ID = int.Parse(id.Text);
            movie.Title = title.Text;
            movie.Year = int.Parse(year.Text);
            movie.Genre = genre.Text;
            movie.RentPrice = float.Parse(rent.Text);
            movie.BuyPrice = float.Parse(buy.Text);

            HttpResponseMessage response = await client.PutAsJsonAsync<Movies>("UpdateMovie/", movie);

            //get the response from restAPI server
            Status1.Content = response.StatusCode.ToString();
        }

        private void table_Click_1(object sender, RoutedEventArgs e)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("Select * from Movie", con);
            SqlDataAdapter adp = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            adp.Fill(ds, "LoadDataBinding");
            datagrid.DataContext = ds;
            con.Close();
        }

        private void purchases_Click(object sender, RoutedEventArgs e)
        {
            PurchasedMovies pm = new PurchasedMovies();
            pm.Show();
        }

        private void accounts_Click(object sender, RoutedEventArgs e)
        {
            RegisteredAccounts ra = new RegisteredAccounts();
            ra.Show();
        }
    }
}
