﻿namespace MovieHub.Models
{
    public class Movies
    {
        public int ID { get; set; }
        public string Title { get; set; }
        public int Year { get; set; }
        public string Genre { get; set; }
        public float RentPrice { get; set; }
        public float BuyPrice { get; set; }
    }
}
