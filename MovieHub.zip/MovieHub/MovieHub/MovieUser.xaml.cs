﻿using Microsoft.VisualBasic;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows;

namespace MovieHub
{
    /// <summary>
    /// Interaction logic for Window12.xaml
    /// </summary>

    public partial class MovieUser : Window
    {
        SqlConnection con = new SqlConnection("Data Source=desktop-qajii73\\sqlexpress;Initial Catalog=Movie;Integrated Security=True");

        public MovieUser()
        {
            InitializeComponent();
        }

        DataTable dt = new DataTable();
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("Select * from Movie", con);
            SqlDataAdapter adp = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            adp.Fill(ds, "LoadDataBinding");
            datagrid.DataContext = ds;

            con.Close();
        }

        private void buy_Click(object sender, RoutedEventArgs e)
        {
            con.Open();
            DataRowView selectedRow = (DataRowView)datagrid.SelectedItem;

            if (selectedRow == null)
            {
                MessageBox.Show("Please Select Movie First!");
            }
            else
            {
                string userInput = Interaction.InputBox("Please enter your Username:", "Input Box", "");
                if (userInput != "")
                {

                    if (selectedRow != null)
                    {
                        var userName = userInput;
                        var title = selectedRow["Title"].ToString();
                        var year = selectedRow["Year"].ToString();
                        var genre = selectedRow["Genre"].ToString();
                        var buyprice = selectedRow["Buy_Price"].ToString();

                        // Check if user has already rented the movie and the expiry date has not passed yet
                        string checkQuery = "SELECT COUNT(*) FROM Purchase WHERE Username COLLATE SQL_Latin1_General_CP1_CS_AS = @Username AND Title = @Title AND (Expiration_Date = 'UNLIMITED' OR Expiration_Date > Purchase_Date)";
                        SqlCommand checkCmd = new SqlCommand(checkQuery, con);
                        checkCmd.Parameters.AddWithValue("@Username", userName);
                        checkCmd.Parameters.AddWithValue("@Title", title);
                        int rentedCount = Convert.ToInt32(checkCmd.ExecuteScalar());

                        if (rentedCount > 0)
                        {
                            MessageBox.Show("This Movie is already Purchased and still Valid");
                        }
                        else
                        {
                            string query = "Select count(*) from Account where username COLLATE SQL_Latin1_General_CP1_CS_AS = @Username";

                            SqlCommand cmd = new SqlCommand(query, con);
                            cmd.Parameters.AddWithValue("Username", userInput);

                            int count = Convert.ToInt32(cmd.ExecuteScalar());

                            if (count == 1)
                            {

                                // Check balance
                                SqlCommand balanceCmd = new SqlCommand("SELECT Balance FROM Payment WHERE Username COLLATE SQL_Latin1_General_CP1_CS_AS = @Username", con);
                                balanceCmd.Parameters.AddWithValue("Username", userInput);
                                var balance = Convert.ToDouble(balanceCmd.ExecuteScalar());

                                if (balance < Convert.ToDouble(buyprice))
                                {
                                    MessageBox.Show("Not enough balance to purchase the movie. Please Add Funds to your account.");
                                }
                                else
                                {
                                    string expirationDate = "UNLIMITED";
                                    DateTime purchaseDate = DateTime.Now;
                                    SqlCommand command = new SqlCommand("SELECT NEXT VALUE FOR MySequence", con);
                                    int seqId = Convert.ToInt32(command.ExecuteScalar());
                                    string insertQuery = "INSERT INTO Purchase (ID, Username, Title, Year, Genre, Price, Purchase_Date, Expiration_Date) " +
                                        "VALUES (@id, @Username, @Title, @Year, @Genre, @Price, @PurchaseDate, @ExpirationDate)";
                                    SqlCommand insertCommand = new SqlCommand(insertQuery, con);

                                    insertCommand.Parameters.AddWithValue("@id", seqId);
                                    insertCommand.Parameters.AddWithValue("@Username", userName);
                                    insertCommand.Parameters.AddWithValue("@Title", title);
                                    insertCommand.Parameters.AddWithValue("@Year", year);
                                    insertCommand.Parameters.AddWithValue("@Genre", genre);
                                    insertCommand.Parameters.AddWithValue("@Price", buyprice);
                                    insertCommand.Parameters.AddWithValue("@PurchaseDate", purchaseDate);
                                    insertCommand.Parameters.AddWithValue("@ExpirationDate", expirationDate);
                                    insertCommand.ExecuteNonQuery();

                                    string updateQuery = "Update Payment SET Payment.Balance = (Payment.Balance - @Price) from Payment inner join Purchase ON Payment.Username = Purchase.Username where Payment.Username = @Username";

                                    SqlCommand insertCommand1 = new SqlCommand(updateQuery, con);
                                    insertCommand1.Parameters.AddWithValue("@Username", userInput);
                                    insertCommand1.Parameters.AddWithValue("@Price", buyprice);
                                    insertCommand1.ExecuteNonQuery();

                                    MessageBox.Show("Movie Purchased Successfully! Enjoy Watching!");
                                }
                            }

                            else
                            {
                                MessageBox.Show("Please Check you Username and Try Again!");
                            }
                        }
                    }
                }
            }
            con.Close();
        }

        private void rent_Click(object sender, RoutedEventArgs e)
        {
            con.Open();
            DataRowView selectedRow = (DataRowView)datagrid.SelectedItem;

            if (selectedRow == null)
            {
                MessageBox.Show("Please Select Movie First!");
            }
            else
            {
                string userInput = Interaction.InputBox("Please enter your Username:", "Input Box", "");
                if (userInput != "")
                {

                    if (selectedRow != null)
                    {
                        var userName = userInput;
                        var title = selectedRow["Title"].ToString();
                        var year = selectedRow["Year"].ToString();
                        var genre = selectedRow["Genre"].ToString();
                        var rentprice = selectedRow["Rent_Price"].ToString();

                        // Check if user has already rented the movie and the expiry date has not passed yet
                        string checkQuery = "SELECT COUNT(*) FROM Purchase WHERE Username COLLATE SQL_Latin1_General_CP1_CS_AS = @Username AND Title = @Title AND Expiration_Date > GETDATE()";
                        SqlCommand checkCmd = new SqlCommand(checkQuery, con);
                        checkCmd.Parameters.AddWithValue("@Username", userName);
                        checkCmd.Parameters.AddWithValue("@Title", title);
                        int rentedCount = Convert.ToInt32(checkCmd.ExecuteScalar());

                        if (rentedCount > 0)
                        {
                            MessageBox.Show("This Movie is already Purchased and still Valid");
                        }
                        else
                        {
                            string query = "Select count(*) from Account where username COLLATE SQL_Latin1_General_CP1_CS_AS = @Username";

                            SqlCommand cmd = new SqlCommand(query, con);
                            cmd.Parameters.AddWithValue("Username", userInput);

                            int count = Convert.ToInt32(cmd.ExecuteScalar());

                            if (count == 1)
                            {

                                // Check balance
                                SqlCommand balanceCmd = new SqlCommand("SELECT Balance FROM Payment WHERE Username COLLATE SQL_Latin1_General_CP1_CS_AS = @Username", con);
                                balanceCmd.Parameters.AddWithValue("Username", userInput);
                                var balance = Convert.ToDouble(balanceCmd.ExecuteScalar());

                                if (balance < Convert.ToDouble(rentprice))
                                {
                                    MessageBox.Show("Not enough balance to purchase the movie. Please Add Funds to your account.");
                                }
                                else
                                {
                                    DateTime expirationDate = DateTime.Now.AddDays(30);
                                    DateTime purchaseDate = DateTime.Now;
                                    SqlCommand command = new SqlCommand("SELECT NEXT VALUE FOR MySequence", con);
                                    int seqId = Convert.ToInt32(command.ExecuteScalar());
                                    string insertQuery = "INSERT INTO Purchase (ID, Username, Title, Year, Genre, Price, Purchase_Date, Expiration_Date) " +
                                        "VALUES (@id, @Username, @Title, @Year, @Genre, @Price, @PurchaseDate, @ExpirationDate)";
                                    SqlCommand insertCommand = new SqlCommand(insertQuery, con);

                                    insertCommand.Parameters.AddWithValue("@id", seqId);
                                    insertCommand.Parameters.AddWithValue("@Username", userName);
                                    insertCommand.Parameters.AddWithValue("@Title", title);
                                    insertCommand.Parameters.AddWithValue("@Year", year);
                                    insertCommand.Parameters.AddWithValue("@Genre", genre);
                                    insertCommand.Parameters.AddWithValue("@Price", rentprice);
                                    insertCommand.Parameters.AddWithValue("@PurchaseDate", purchaseDate);
                                    insertCommand.Parameters.AddWithValue("@ExpirationDate", expirationDate);
                                    insertCommand.ExecuteNonQuery();

                                    string updateQuery = "Update Payment SET Payment.Balance = (Payment.Balance - @Price) from Payment inner join Purchase ON Payment.Username = Purchase.Username where Payment.Username = @Username";

                                    SqlCommand insertCommand1 = new SqlCommand(updateQuery, con);
                                    insertCommand1.Parameters.AddWithValue("@Username", userInput);
                                    insertCommand1.Parameters.AddWithValue("@Price", rentprice);
                                    insertCommand1.ExecuteNonQuery();

                                    MessageBox.Show("Movie Purchased Successfully! Enjoy Watching!");
                                }
                            }

                            else
                            {
                                MessageBox.Show("Please Check you Username and Try Again!");
                            }
                        }
                    }
                }
            }
            con.Close();
        }

        private void history_Click(object sender, RoutedEventArgs e)
        {
            PurchaseHistory ph = new PurchaseHistory();
            ph.Show();
        }

        private void balance_Click(object sender, RoutedEventArgs e)
        {
            con.Open();
            string username = Interaction.InputBox("Please enter your Username:", "Input Box", "");
            if (username != "")
            {
                string query = "SELECT COUNT(*) FROM Payment WHERE Username COLLATE SQL_Latin1_General_CP1_CS_AS = @Username";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@Username", username);

                int count = Convert.ToInt32(cmd.ExecuteScalar());

                if (count == 1)
                {
                    query = "SELECT Balance FROM Payment WHERE Username COLLATE SQL_Latin1_General_CP1_CS_AS = @Username";
                    cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@Username", username);

                    SqlDataReader sqlReader = cmd.ExecuteReader();
                    while (sqlReader.Read())
                    {
                        MessageBox.Show("Your Account Balance is: $" + sqlReader.GetValue(0).ToString());
                        break;
                    }
                    sqlReader.Close();
                }
                else
                {
                    MessageBox.Show("No payment card is registered for this user. Please register a payment card first.");
                }
            }
            con.Close();
        }

        private void addFunds_Click(object sender, RoutedEventArgs e)
        {
            con.Open();
            string userInput = Interaction.InputBox("Please enter your Username:", "Input Box", "");
            if (userInput != "")
            {
                string user = "Select count(*) from Account where username COLLATE SQL_Latin1_General_CP1_CS_AS = @Username";

                SqlCommand cmd1 = new SqlCommand(user, con);

                cmd1.Parameters.AddWithValue("Username", userInput);
                int count = Convert.ToInt32(cmd1.ExecuteScalar());

                if (count == 1)
                {
                    string amountInput = Interaction.InputBox("Please enter the deposit amount:", "Input Box", "");
                    decimal amount = 0;
                    if (decimal.TryParse(amountInput, out amount) && amount > 0)
                    {
                        string query = "Select count(*) from Payment where username COLLATE SQL_Latin1_General_CP1_CS_AS = @Username";

                        SqlCommand cmd = new SqlCommand(query, con);
                        cmd.Parameters.AddWithValue("Username", userInput);

                        int count1 = Convert.ToInt32(cmd.ExecuteScalar());
                        if (count1 == 1)
                        {
                            string query1 = "Update Payment set Balance = Balance + @Balance where Username COLLATE SQL_Latin1_General_CP1_CS_AS = @Username";

                            SqlCommand com = new SqlCommand(query1, con);

                            com.Parameters.AddWithValue("@Balance", amount);
                            com.Parameters.AddWithValue("@Username", userInput);

                            com.ExecuteNonQuery();

                            MessageBox.Show("$" + amount.ToString() + " Has been added into your Account");
                        }
                        else
                        {
                            MessageBox.Show("Payment Card does not Exist!");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Invalid deposit amount!");
                    }
                }
                else
                {
                    MessageBox.Show("Invalid Username!");
                }
            }
            else
            {
                MessageBox.Show("Please Check your Username and Try Again!");
            }
            con.Close();
        }

        private void newCard_Click(object sender, RoutedEventArgs e)
        {
            AddCard ad = new AddCard();
            ad.Show();
        }

        private void watch_Click(object sender, RoutedEventArgs e)
        {
            PurchasedMovieList pml = new PurchasedMovieList();
            pml.Show();
            this.Close();
        }

        private void logout_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Account Logged out Successfully");
            MainWindow mn = new MainWindow();
            mn.Show();
            this.Close();
        }
    }
}