﻿using System.Data.SqlClient;
using System.Windows;
using System.Text.RegularExpressions;
using System;
using System.Reflection;

namespace MovieHub
{
    /// <summary>
    /// Interaction logic for Register.xaml
    /// </summary>
    public partial class Register : Window
    {
        SqlConnection con;
        public Register()
        {
            InitializeComponent();
        }

        private void register_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string connectionString = "Data Source=DESKTOP-QAJII73\\SQLEXPRESS;Initial Catalog=Movie;Integrated Security=True";
                con = new SqlConnection(connectionString);
                con.Open();
                if (string.IsNullOrEmpty(fName.Text) || string.IsNullOrEmpty(lName.Text) || string.IsNullOrEmpty(email.Text) || string.IsNullOrEmpty(dob.Text) || string.IsNullOrEmpty(username.Text) || string.IsNullOrEmpty(password.Text))
                {
                    MessageBox.Show("Please fill all the fields!");
                }
                else
                {
                    string usernameRegex = @"^(?!.*\s).{6,15}$";
                    Regex regex = new Regex(usernameRegex);
                    Match match = regex.Match(username.Text);

                    string passwordRegex = @"^(?=.*[A-Z])(?=.*[a-z])(?=.*[0-9])(?=.*[!-~])(?!.*\s).{6,15}$";
                    Regex regex1 = new Regex(passwordRegex);
                    Match match1 = regex.Match(password.Text);

                    string emailRegex = @"^[^\s@]+@[^\s@]+\.[^\s@]+$";
                    Regex regex2 = new Regex(emailRegex);
                    Match match2 = regex2.Match(email.Text);

                    if (!match.Success)
                    {
                        MessageBox.Show("Invalid Username! \n-Password should contain no space" +
                                        "\n-Length should be between 6 to 15 characters");

                    }
                    else if (!match1.Success)
                    {
                        MessageBox.Show("Invalid Password! \n-Password should contain no space" +
                                        "\n-Length should be between 6 to 15 characters" +
                                        "\n-At least 1 number" +
                                        "\n-Should contain at least 1 lowercase letter" +
                                        "\n-Should contain at least 1 uppercase letter" +
                                        "\n-Should contain at least 1 special character");
                    }
                    else if (!match2.Success)
                    {
                        MessageBox.Show("Invalid Email Address!");
                    }
                    else
                    {
                        string query = "Insert into Account values(@Username, @Password, @First_name, @Last_name, @Date_of_birth, @Email)";
                        SqlCommand cmd = new SqlCommand(query, con);
                        cmd.Parameters.AddWithValue("Username", username.Text);
                        cmd.Parameters.AddWithValue("Password", password.Text);
                        cmd.Parameters.AddWithValue("First_name", fName.Text);
                        cmd.Parameters.AddWithValue("Last_name", lName.Text);
                        cmd.Parameters.AddWithValue("Date_of_birth", dob.Text);
                        cmd.Parameters.AddWithValue("Email", email.Text);

                        //Execute the query
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Account Registered!");
                        this.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}");
            }

            con.Close();
        }

        private void back_Click(object sender, RoutedEventArgs e)
        {
            MainWindow main = new MainWindow();
            main.Show();
            this.Close();
        }
    }
}
