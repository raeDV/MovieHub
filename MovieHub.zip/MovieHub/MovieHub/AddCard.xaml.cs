﻿using Microsoft.VisualBasic;
using System;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
using System.Windows;

namespace MovieHub
{
    /// <summary>
    /// Interaction logic for AddCard.xaml
    /// </summary>
    public partial class AddCard : Window
    {
        SqlConnection con = new SqlConnection("Data Source=desktop-qajii73\\sqlexpress;Initial Catalog=Movie;Integrated Security=True");

        public AddCard()
        {
            InitializeComponent();
        }

        private void addCard_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                con.Open();
                string emailRegex = @"^[^\s@]+@[^\s@]+\.[^\s@]+$";
                Regex regex = new Regex(emailRegex);
                Match match = regex.Match(email.Text);

                if (string.IsNullOrEmpty(fName.Text) || string.IsNullOrEmpty(lName.Text) || string.IsNullOrEmpty(email.Text) || string.IsNullOrEmpty(dob.Text) || string.IsNullOrEmpty(phone.Text) || string.IsNullOrEmpty(gender.Text))
                {
                    MessageBox.Show("Please fill all the fields!");
                }
                else if (!match.Success)
                {
                    MessageBox.Show("Invalid Email Address!");
                }
                else
                {
                    string username = Interaction.InputBox("Please enter your Username:", "Input Box", "");
                    if (username != "")
                    {
                        string query = "Select count(*) from Account where Username COLLATE SQL_Latin1_General_CP1_CS_AS = @Username";

                        SqlCommand cmd = new SqlCommand(query, con);
                        cmd.Parameters.AddWithValue("Username", username);

                        int count = Convert.ToInt32(cmd.ExecuteScalar());

                        if (count == 1)
                        {
                            string query2 = "Select count(*) from Payment where username COLLATE SQL_Latin1_General_CP1_CS_AS = @Username";

                            SqlCommand comm = new SqlCommand(query2, con);
                            comm.Parameters.AddWithValue("Username", username);

                            int count1 = Convert.ToInt32(comm.ExecuteScalar());
                            if (count1 == 1)
                            {
                                MessageBox.Show("Account Card Already Registered!");
                            }
                            else
                            {
                                float balance = 0;
                                string query1 = "Insert into Payment values(@Username, @First_name, @Last_name, @Phone, @Email, @Date_of_birth, @Gender, @Balance)";
                                SqlCommand com = new SqlCommand(query1, con);
                                com.Parameters.AddWithValue("Username", username);
                                com.Parameters.AddWithValue("First_name", fName.Text);
                                com.Parameters.AddWithValue("Last_name", lName.Text);
                                com.Parameters.AddWithValue("Email", email.Text);
                                com.Parameters.AddWithValue("Date_of_birth", dob.Text);
                                com.Parameters.AddWithValue("Phone", phone.Text);
                                com.Parameters.AddWithValue("Gender", gender.Text);
                                com.Parameters.AddWithValue("Balance", balance);

                                //Execute the query
                                com.ExecuteNonQuery();
                                MessageBox.Show("Card Registered Successfully!");
                                this.Close();
                            }
                        }
                        else
                        {
                            MessageBox.Show("This Username is not valid, Please Sign Up First");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please Check you Username and Try Again!");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            con.Close();
        }
    }
}
