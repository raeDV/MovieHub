﻿using Microsoft.VisualBasic;
using System.Data.SqlClient;
using System.Data;
using System.Windows;
using System;

namespace MovieHub
{
    /// <summary>
    /// Interaction logic for PurchaseHistory.xaml
    /// </summary>
    public partial class PurchaseHistory : Window
    {
        SqlConnection con = new SqlConnection("Data Source=desktop-qajii73\\sqlexpress;Initial Catalog=Movie;Integrated Security=True");

        public PurchaseHistory()
        {
            InitializeComponent();
        }
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            con.Open();
            string userInput = Interaction.InputBox("Please enter your Username:", "Input Box", "");
            if (userInput != "")
            {
                string user = "Select count(*) from Account where username COLLATE SQL_Latin1_General_CP1_CS_AS = @Username";

                SqlCommand cmd1 = new SqlCommand(user, con);

                cmd1.Parameters.AddWithValue("Username", userInput);
                int count = Convert.ToInt32(cmd1.ExecuteScalar());

                if (count == 1)
                {
                    SqlCommand cmd = new SqlCommand("Select * from Purchase where Username COLLATE SQL_Latin1_General_CP1_CS_AS = @Username", con);
                    cmd.Parameters.AddWithValue("Username", userInput);
                    cmd.ExecuteScalar();
                    SqlDataAdapter adp = new SqlDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    adp.Fill(ds, "LoadDataBinding");
                    datagrid.DataContext = ds;
                }
                else
                {
                    MessageBox.Show("Account does not Exist!");
                    this.Close();
                }
            }
            con.Close();
        }
    }
}
